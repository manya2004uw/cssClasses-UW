public class Stack {
    //private data member 
    private ArrayList list;

    /**Stack()
     * Descripti0on: Constructor instantiates new instace of Stack 
     * PRE: none
     * POST: new Stack object 
     * 
     */
    public Stack() {
        list = new ArrayList(); //new ArrayList is set to list this will be what Stack uses 
    }


    /** void push(Object obj)
     * @param obj
     * Description: inserts element at the start of the list like FIFO is a void method 
     * PRE: none
     * POST: new element is inserted at list 
     */
    public void push(Object obj) {
        list.insert(obj, 0);  //use insert from ArrayList and insert at indedx 0 
    }


    /** Object pop()
     * @return
     * Description: remove the first index from Stack or first element 
     * PRE: Stack shouldn't be empty
     * POST: return stack without index being popped 
     */
    public Object pop() {
        if (list.isEmpty()) //if list is empty throw an excepton
            throw new IllegalStateException("Stack is empty");

        return list.remove(0); //return list after removing index 0 
    }

    /** int size()
     * @return int
     * Descripti9on: returns size of stack using size method from ArrayList
     * PRE: none
     * POST: returns int size 
     */
    public int size() {
        return list.size();
    }

    /*String toString()
    Description: returns a string implementation of stack 
    PRE: none
    POST: returns a string implementation of stack 
     * 
     */
    public String toString() {
        if (list.size() == 0) { //if size is empty return empty indices 
            return "[]";
        }

        //initialize str as [
        String str = "[ ";
        //for loop iterates backwords printing from top to bottom 
        for (int i = list.size() - 1; i >= 0; i--) {
        str += list.get(i);
        }

        return str;  //return str 
    }

    /**boolean isEmpty()
     * @return true or false
     * Descripti9on: if stack is empty return true otherwise return false
     * PRE: none
     * POST: return true or false; 
     */
    public boolean isEmpty() {
        return list.isEmpty(); //call isEmpty from ArrayList 
    }


    /** boolean equals(Stack other)
     * @param other
     * @return true or false 
     * Descripti9on: if stack object equals other, it will return true otherwise returns false 
     * PRE: none
     * POST: return true or false 
     */
    public boolean equals(Stack other) {
        return list.equals(other.list); //use equals method from ArrayList to check if lists from both stacks are equ8ivelent
    }
}
