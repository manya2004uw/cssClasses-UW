public class ArrayList {

    //private data members 
    Object [] array;  //type object 
    private int size; //type int 

/* ArrayList() Constructor 
 * Description: Constructor for ArrayList class instantiates a new instance
 * of the class with an array of 0 and size 0. The array will be populated by the user 
 * PRE: none
 * POST: creates an empty ArrayList 
 * 
 * 
 */
    public ArrayList() {
        array = new Object[0]; // declare an array
        size = 0; //size is set to 0 
    }

    /* void insert(Object obj, int index)
     * Description: inserts an object at specified index of arraylist
     * Parameters are an object and index 
     * PRE: none
     * POST: sets newArray to array void return type 
     * 
     * 
     */
    public void insert(Object obj, int index) {

        Object[] newArray = new Object[++size]; //declare newArray with size incremented by one to make space for new element 

        //for loop runs throw contents of newArray and adds elements 
        for (int i = 0; i < size; i++) {
            if (i == index) { //if i = index, newArray at that index will contain the object from parameter 
                newArray[i] = obj;
            }
             if (i > index) { //if i is greater than index, elements of newArray will be 1 less than array 
                newArray[i] = array[i-1];
            }
             if ( i < index) { //if i < index, elements are the same 
            newArray[i] = array[i];
            }

        }
        array = newArray;
        //set array to newArray 

        
}

/*String toString()
Descripti9on: Returns a String implementation of ArrayList object 
no parameters 
 * PRE: none
 * POST: returns a string of ArrayList
 * 
 */
public String toString() {
    if (array.length == 0) {
    // if array is empty 
     return "[]"; //return empty index 
    }
    String str = ""; //initialize string str 
    for (int i = 0; i < size; i++) { //for loop iterates through contents of ArrayList
     str += array[i] + " "; // adds object to String 
}
return str; //return str 
}

/* Object remove(int index)
 * Description: removes an element at specified index in parameter and is of type Object since
 * it returns object removed at specified index 
 * PRE: index passed in argument is greater than 0, and is less than or equal to size 
 * POST: returns object removed at specified index 
 */
public Object remove(int index) {
    // throw outofbounds exception if index is out of bounds 
    if (index < 0 || index >= size) {
        throw new ArrayIndexOutOfBoundsException("out of bounds");
    }
    //declare object as null 
    Object store = null; 

    //create newArray of --size 
    Object [] newArray = new Object[--size]; 
    //iterate through contents of newArray
    for (int i = 0; i <= size - 1; i++) {
        if (i >= index) { //if i >= index elements shfted to the left 
            newArray[i] = array[i+1]; 
        }
        else {
            newArray[i] = array[i]; //else elements are the same as the one in array
        }
    }
    array = newArray; //set newArray to array
    return store; 
    //return Object store 
    
}

/*int size()
Description: returns size of arraylist object 
PRE: arraylist exists
POST: returns length of ArrayList object.
 * 
 */
public int size() {
    return size; 
}

/*boolean isEmpty()
Description: returns true or false depending on whether the ArrayList is empty 
PRE: none
POST: returns true or false; 
 * 
 */
public boolean isEmpty() {
    return size == 0; 
}

/* boolean equals(ArrayList another)
 * Description: compares two ArrayList objects and checks is elements are the same in the same order and both
 * are of the same size takes in another ArrayList object and returns true or false
 * PRE: none
 * POST: returns true or false 
 */
public boolean equals(ArrayList another) {
    //check if sizes are equal if they are not immediately return false
    if (this.size != another.size) {
        return false; 
    }

    // use a for loop to iterate through contents of both arrays 
    for (int i = 0; i < size; i++) {
        if (!(this.array[i].equals(another.array[i]) == true)) { //if two elements are not equal return false 
            return false; 
        }
    }
    return true; //return true if didn't return false in for loop 
}

/* Object get(int index)
 * Description: return element at specified index in parameter
 * PRE: index is within bounds of array
 * POST: returns object at index specified 
 */
public Object get(int index) {
    if (index >= array.length) { //if index is out of bounds 
        throw new ArrayIndexOutOfBoundsException("Index is out of bounds"); //throw exception
    }

return array[index]; //return object 
}

}

