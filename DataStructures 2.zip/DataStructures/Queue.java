

public class Queue {
    //private data member list of type ArrayList 
    private ArrayList list;  

    
    /** Queue constructor
     * Descripti9on: Instantiates Queue object 
     * PRE: none
     * POST: new Queue object 
     * 
     */
    public Queue() {
        list = new ArrayList(); ;// list is equal to new ArrayList 
    }


    /** void enqueue
     * @param obj
     * Description: inserts an object at the end of a list like LIFO and is void 
     * PRE: none
     * POST: inserts object at end of queue
     */
    public void enqueue(Object obj) {
        list.insert(obj, list.size()); //calls insert from ArrayList class at the end of the queue
    }


/** Object dequeue()
 * @return
 * Description: removes first element of list, or the first element as in LIFO
 * PRE: none
 * POST: returns list without object dequeued 
 */
public Object dequeue() {
        if (list.isEmpty())
            throw new ArrayIndexOutOfBoundsException("queue is empty"); //throw new exception if queue is empty 

        return list.remove(0); //returns list without the first element 
    }

    /** int size()
     * @return int 
     * Description: returns the size of Queue object
     * PRE: none
     * POST: returns the size of Queue as int 
     */
    public int size() {
        return list.size(); 
    }

  /* String toString()
  @return String
  Description: returns a string implementaion of 
  queue 
  PRE: none
  POST: string implementation 
  */  
    public String toString() {
        if(list.isEmpty()) { //is list is empty, return empty indices 
            return "[]";
        }
        String str = "[ "; //intiialize str 

        for (int i = 0; i < list.size(); i++) { // iterate through for loop
            str += list.get(i); //increment indexes of array to string 

    }
    return str + "] "; //return final string 
}


    /** boolean isEmpty()
     * @return
     * Description: returns true or false depending on whether list is empty 
     * PRE: none
     * POST: returns true or false 
     */
    public boolean isEmpty() {
        return list.isEmpty(); // return 
    }

    /** boolean equals(Queue other)
     * @param other
     * @return boolean
     * Description: if queue equals other queue object return true 
     * PRE: none
     * POST: return true or false 
     */
    public boolean equals(Queue other) {
        return list.equals(other.list); //using equals from ArrayList will compare the two lists 
    }

}