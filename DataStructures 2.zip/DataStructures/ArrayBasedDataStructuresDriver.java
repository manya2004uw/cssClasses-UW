/*
 *  Incomplete Driver (and testing harness) for ArrayList, Stack, and Queue
 *
 *
 */

import java.util.ArrayList;
import java.util.Queue;
import java.util.Stack;

public class ArrayBasedDataStructuresDriver {
    public static void main(String[] args) {
        stackTests();
        queueTests();
        arrayListTests();
        Queue a = new Queue();
        a.enqueue("b");
        a.enqueue("dd");
        a.toString();
        a.dequeue();
        a.toString();
        ArrayList ab = new ArrayList();
        int i = 5;
        int i2 = 6; 
        int i3 = 2;
        Integer newi = Integer.valueOf(i);
        Integer newi2 = Integer.valueOf(i2);
        Integer newi3 = Integer.valueOf(i3);
        ab.insert((Object)newi,0);
        ab.insert((Object)i2,1);
        ab.insert((Object)i3,2);
        ab.insert((Object)Integer.valueOf(7),1);
        System.out.println(a.toString());
        ab.remove(1);
        System.out.println(a.toString());
        ArrayList empty = new ArrayList();
        System.out.println(empty.isEmpty());
        empty.insert((Object)Integer.valueOf(3),0);
        System.out.println(empty.isEmpty());
        ArrayList copy1 = new ArrayList();
        ArrayList copy2 = new ArrayList();
        copy1.insert((Object)Integer.valueOf(5), 0);
        copy2.insert((Object)Integer.valueOf(5),0);
        System.out.println(copy1.equals(copy2));
        System.out.println(copy1.equals(a));

    }

    /**
     * arrayListTests
     * ----------
     * This method runs all the tests on the ArrayList class
     */
    private static void arrayListTests() {
        System.out.println("ArrayList Tests: ");
        //todo: make more tests here
        ArrayList a = new ArrayList();
        ArrayList b = new ArrayList();
        a.add(0, 'B');
        a.add(0, 'a');
        a.add(1, 't');
        b.add(8,"b");
        // It should now be [a,t,B

        // ArrayList's toString should print 0 index element to last element:
        System.out.println("This should print out 'atB': " + a.toString());

        System.out.println("This should print out a, t, B (in that order), on separate lines: ");
        while(a.isEmpty() == false) {
            System.out.println(a.remove(0));
        }

        test("ArrayList is empty", a.isEmpty());
        a.add(-99, 'X'); // attempt to insert at index -99. This should fail.
        test("Cannot add at negative index", a.isEmpty());

        System.out.println(); // just for an extra line to separate tests and make things neater
    }

    /**
     * queueTests
     * ----------
     * This method runs all the tests on the Queue class
     */
    private static void queueTests() {
        System.out.println("Queue Tests: ");
        //todo: make more tests here
        Queue q = new Queue();
        Queue que = new Queue();
        q.enqueue('B');
        q.enqueue('a');
        q.enqueue('t');
        que.enqueue("b");
        que.enqueue("d");
        q.equals(que);

        // B is at the front of the queue, t is at the back.

        // Queue's toString prints front to back:
        System.out.println("This should print 'Bat': " + q.toString());

        System.out.println("This should print out B, a, t (in that order), on separate lines: ");
        while(q.isEmpty() == false) {
            System.out.println(q.dequeue());
        }
        System.out.println(); // just for an extra line to separate tests and make things neater
    }

    /**
     * stackTests
     * ----------
     * This method runs all the tests on the Stack class
     */
    private static void stackTests() {
        System.out.println("Stack Tests: ");
        //todo: make more tests here
        Stack s = new Stack();
        Stack ok = new Stack();
        s.push('B');
        s.push('a');
        s.push('t');
        ok.push("g");
        ok.push("l");
        s.equals(ok);
        // B should be at the bottom of the Stack, t should be on top.

        // Stack's toString prints top to bottom:
        System.out.println("This should print 'taB': " + s.toString());

        System.out.println("This should print out t, a, B (in that order), on separate lines: ");
        while(s.isEmpty() == false) {
            System.out.println(s.pop());
        }
        System.out.println(); // just for an extra line to separate tests and make things neater
    }

    /**
     * test
     * ----
     * a simple method to make testing easier.
     * This returns a message saying the testName has passed if testIsTrue,
     * or a message saying its failed otherwise.
     */
    public static void test(String testName, boolean testIsTrue){
	if (testIsTrue)
            System.out.println("PASSED: " + testName );
	else
            System.out.println("FAILED: " + testName );
    }

    
        


}
