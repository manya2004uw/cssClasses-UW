import java.util.List;

public class BoardTest {
    public static void main(String[] args) {
        testPlacePiece();
        testGetWinnerX();
        testGetWinnerO();
        testIsGameDraw();
        testGetAvailableMoves();
    }

    public static void testPlacePiece() {
        Board board = new Board();
    System.out.println("Test Place Piece:");
    
    // Attempt to place a piece at (0, 0)
    board.placePiece(0, 0); // Valid move
    
    // Check if the piece was placed correctly
    String pieceAt00 = board.getPiece(0, 0); // Assume there's a method to get the piece at a specific position
    System.out.println("Piece at (0, 0) (should be 'X'): " + pieceAt00);
    
    // Attempt to place a piece at (0, 0) again
    board.placePiece(0, 0); // Invalid move
    
    // Check if the piece is still the same
    String pieceAt00AfterSecondAttempt = board.getPiece(0, 0);
    System.out.println("Piece at (0, 0) after second attempt (should still be 'X'): " + pieceAt00AfterSecondAttempt);
    
    // Place another piece in a different position
    board.placePiece(1, 0); // Valid move
 String pieceAt10 = board.getPiece(1, 0);
    System.out.println("Piece at (1, 0) (should be 'O'): " + pieceAt10);
    }

    public static void testGetWinnerX() {
        Board board = new Board();
        board.placePiece(0, 0); // X
        board.placePiece(1, 0); // O
        board.placePiece(0, 1); // X
        board.placePiece(1, 1); // O
        board.placePiece(0, 2); // X

        System.out.println("Test Winner for X (should be 1): " + board.getWinner());
    }

    public static void testGetWinnerO() {
        Board board = new Board();
        board.placePiece(0, 0); // X
        board.placePiece(1, 0); // O
        board.placePiece(0, 1); // X
        board.placePiece(1, 1); // O
        board.placePiece(2, 1); // X
        board.placePiece(1, 2); // O
    
        System.out.println("Test Winner for O (should be 2): " + board.getWinner());
    }
    

    public static void testIsGameDraw() {
        Board board = new Board();
        // Fill the board with a draw situation
        board.placePiece(0, 0); // X
        board.placePiece(0, 1); // O
        board.placePiece(0, 2); // X
        board.placePiece(1, 0); // O
        board.placePiece(1, 1); // X
        board.placePiece(1, 2); // O
        board.placePiece(2, 0); // O
        board.placePiece(2, 1); // X
        board.placePiece(2, 2); // O
    
        System.out.println("Test Game Draw (should be true): " + board.isGameDraw()); // Should print true
    }

    public static void testGetAvailableMoves() {
        Board board = new Board();
        board.placePiece(0, 0); // X
        List<int[]> availableMoves = board.getAvailableMoves();

        System.out.println("Test Available Moves (should be 8): " + availableMoves.size());
    }
}
