
import java.util.*;

/**
 * This class keeps track of the board and controls access to the board's pieces.
 * 
 * It has a copy constructor.
 * 
 * It can:
 *     make a move on the board (place a piece)
 *     give a list of moves available yet to be made
 *     display itself via toString()
 *     determine whose move it is
 *     determine if there is a winner or a draw
 * 
 * @author Manya Chugh
 *
 */
public class Board {

   /* Your Board class should have very few instance fields.
    * All instance fields will be private.
    * 
    * The board HAS-A storage for all the X & O pieces on the board.
    * Students should write comments that explain how an X vs O is represented.
    * 
    * The board class may HAS-A count of the X's and O's pieces on the board.
    * How you store the pieces on the board can make your code simple or complex.
    * Think about how you want a move (or location on the board) to be easily
    * represented, and how you would store a piece at that location.
    * Here are 6 typical ways that students have stored the board:
    *       - String
    *       - int[] 
    *       - int[][]
    *       - String[]
    *       - String[][]
    *       - char[][]
    * 
    * That's it. No more instance fields!
    */
	private String [][] arr;
	private String currentPlayer = "X"; // Tracks whose turn it is

   /**
    * This constructor will create an empty board.
    */
	public Board() {
		arr = new String [3][3];

		// set all poeces to .
		for (int row = 0; row < arr.length; row++) {
			for (int col = 0; col < 3; col++) {
				arr[row][col] = "."; //perdiod means empty space 
			}

		}

		
	


	}
	
	/**
	 * The Copy Constructor will do a DEEP copy of an existing Board.
	 * @param copyMe The Board to copy.
	 */
	public Board(Board copyMe) {
		arr = new String[3][3]; //3x3 stringds are immutable i tink 

		for (int row = 0; row < arr.length; row++) {
			for (int col = 0; col < 3; col++) {
				arr[row][col] = copyMe.arr[row][col];
			}
		}
		this.currentPlayer = copyMe.currentPlayer;




	}
	
	/* There should be a getter for a piece on the board at a specific
	 * location. Avoid "privacy leaks". This means, do not return a reference
	 * to an object/array that breaks the Board's ability to protect & control
	 * the values of an instance field.
	 *
	 * To avoid a "privacy leak", simply return the piece (X/O) at a specific
	 * location. Do not return the data structure that contains the pieces.
	 */
	// TODO: implement the getter to get a piece on the board

	public String getPiece(int row, int col) {
		if (row >= 0 && row < 3 && col >= 0 && col < 3) {
			Board copy = new Board(this);
			return copy.arr[row][col]; // Return the piece at the specified location on copy to avoid privacy leaks ig?
		}
		throw new IndexOutOfBoundsException("try again in bounds 0 - 3"); //throws exception 
	}

	public String getCurrentPlayer() {
		return this.currentPlayer; //get currentpkayer
	}

	
	
	// You may want a method that returns whose move is next. i.e. which piece
	// should be placed on the board next. This is easy to do when you know how
	// many pieces are on the board.
	// TODO: implement the ability to discover which piece moves next
	//public 

	
	// The board must be able to print itself nicely. 
	public String toString() {
		StringBuilder str = new StringBuilder();
    for (int row = 0; row < this.arr.length; row++) {
        str.append("|| ");
        for (int col = 0; col < this.arr[row].length; col++) {
            str.append(this.getPiece(row, col) + " | ");
        }
        str.append("||\n");
    }
    return str.toString();
	}
	
	/* The Board can make a move */
	// TODO: Implement the ability to place a piece at a given location.


	//helper method to place a piece 
	public void placePiece(int row, int col) {
		if (row >= 0 && row < 3 && col >= 0 && col < 3 && this.arr[row][col].equals( ".")) {
			this.arr[row][col] = currentPlayer;
			currentPlayer = currentPlayer.equals("X") ? "O" : "X"; //ternarys exprwssions simplify everything tg 
		}

		
	}

	public void placeRandomMove() {
		List<int[]> availableMoves = getAvailableMoves(); // Get da list 
	
		
		if (!availableMoves.isEmpty()) {
			Random random = new Random();
			int[] randomMove = availableMoves.get(random.nextInt(availableMoves.size())); 
	
			// Place the piece at the random position use Random random 
			int row = randomMove[0];
			int col = randomMove[1];
			placePiece(row, col); 
		}
	}

	

	
	/*
	 * Implement a method to get the moves that are available to make.
	 * Do NOT return a reference to any instance fields.
	 * 
	 * You may return an array or a List of moves.
	 * Create the array/list of moves in this method.
	 * 
	 * Depending on how you store your pieces, a move will be a single
	 * integer, or an array of two integers.
	 */
	// TODO: implement a method to get the moves that are available to make.
	public List<int[]> getAvailableMoves() {
		List<int[]> moves = new ArrayList<>(); //int [] stores two integers, x and y coordinate 
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 3; col++) {
				if (arr[row][col].equals(".")) {
					moves.add(new int[] {row, col}); //doesnt return a reference to instance fields but instead a copy to avoid privacy leaks 
				}
			}
		}
		return moves;
	}
	
	public boolean isBoardFull() { //checks if board is empty created to help countWins in main and BoardTest class i made for testing 
	for (int row = 0; row < arr.length; row++) {
        for (int col = 0; col < arr[row].length; col++) {
            if (arr[row][col].equals(".")) { 
                return false; // Found an empty so the board is not full
            }
        }
    }
    return true; //  so the board is full
}

	/*
	 * The board can figure out if there is a winner, or if the game
	 * has ended in a draw. You may want to have two different methods
	 * to provide this behavior, such as: isGameDraw(), getWinner().
	 * Or, you can encode all 4 possibilities into a single method.
	 * getGameState():  0=Draw. 1=X wins. 2=O wins. 3=game not over.
	 * How you choose to do this is is completely up to you.
	 */
	// TODO: implement the ability to determine a winner/draw.

	public int getWinner () {
// check all possibilities for a win be it rows culumns or diagnols 

for (int i = 0; i < 3; i++) {
	// Row check
	if (!arr[i][0].equals(".") && arr[i][0].equals(arr[i][1]) && arr[i][1].equals(arr[i][2])) {
		return arr[i][0].equals("X") ? 1 : 2;
	}
	// Column check
	if (!arr[0][i].equals(".") && arr[0][i].equals(arr[1][i]) && arr[1][i].equals(arr[2][i])) {
		return arr[0][i].equals("X") ? 1 : 2;
	}
}

// Check diagonals
if (!arr[0][0].equals(".") && arr[0][0].equals(arr[1][1]) && arr[1][1].equals(arr[2][2])) {
	return arr[0][0].equals("X") ? 1 : 2;
}
if (!arr[0][2].equals(".") && arr[0][2].equals(arr[1][1]) && arr[1][1].equals(arr[2][0])) {
	return arr[0][2].equals("X") ? 1 : 2;
}



return 0;
		
	
}
 
public boolean isGameDraw() {
    if (getWinner() != 0) {
        return false;
    }

    // Check for any remaining empty spots
    for (int row = 0; row < 3; row++) {
        for (int col = 0; col < 3; col++) {
            if (arr[row][col].equals(".")) {
                return false; 
            }
        }
    }

    return true; //draw 
}
	



}
