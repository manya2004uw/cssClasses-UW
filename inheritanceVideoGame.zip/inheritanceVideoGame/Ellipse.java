import java.awt.*;

/**
 * Ellipse
 * -------
 * Represents an ellipse shape on a graphics canvas.
 * Extends the Shape class and implements methods for area calculation and drawing.
 * 
 */
public class Ellipse extends Shape {

    private int majorAxis;          // The length of the major axis of the ellipse
    private int minorAxis;          // The length of the minor axis of the ellipse
    private Color ellipseColor;     // The color of the ellipse

    /**
     * Constructs an Ellipse object with the specified coordinates, major axis length, and minor axis length, using the default color (RED).
     * 
     * @param x The x-coordinate of the center of the ellipse
     * @param y The y-coordinate of the center of the ellipse
     * @param majorAxis The length of the major axis of the ellipse (must be greater than 0)
     * @param minorAxis The length of the minor axis of the ellipse (must be greater than 0)
     * @pre majorAxis and minorAxis must be greater than 0
     * @post constructs an Ellipse obbject 
     */
    public Ellipse(int x, int y, int majorAxis, int minorAxis) {
        super(x, y); //call parent constructor 
        if (majorAxis < 0) {
            this.majorAxis = 20; 
        }
        else {
        this.majorAxis = majorAxis;
    }
    if (minorAxis < 0) {
        this.minorAxis = 20; 
    }
    else {
        this.minorAxis = minorAxis;
    }
        this.ellipseColor = Color.RED; // Default color is red
    }

    /**
     * Constructs an Ellipse object with the specified coordinates, major axis length, minor axis length, and color.
     * 
     * @param x The x-coordinate of the center of the ellipse
     * @param y The y-coordinate of the center of the ellipse
     * @param majorAxis The length of the major axis of the ellipse (must be greater than 0)
     * @param minorAxis The length of the minor axis of the ellipse (must be greater than 0)
     * @param c The color of the ellipse (not null)
     * @pre majorAxis and minorAxis must be greater than 0
     * @pre c is not null
     * @post constructs ellipse object 
     */
    public Ellipse(int x, int y, int majorAxis, int minorAxis, Color c) {
        super(x, y); //call parent constructor 
        
if (majorAxis < 0) {
            this.majorAxis = 20; 
        }
        else {
        this.majorAxis = majorAxis;
    }
    if (minorAxis < 0) {
        this.minorAxis = 20; 
    }
    else {
        this.minorAxis = minorAxis;
    }       
        this.ellipseColor = c;
    }

    /**
     * Calculates and returns the area of the ellipse.
     * 
     * @return The area of the ellipse (π * majorAxis * minorAxis)
     * @pre object calles is not null 
     * @post returns area 
     * 
     */
    @Override
    public double getArea() {
        return Math.PI * majorAxis * minorAxis;
    }

    /**
     * Draws the ellipse on the specified graphics context.
     * 
     * @param g The graphics context on which to draw the ellipse
     * @pre not null 
     * @post Ellipse is drawn on the graphics context
     */
    @Override
    public void draw(Graphics g) {
        g.setColor(ellipseColor);
        g.fillOval(getX() - majorAxis, getY() - minorAxis, 2 * majorAxis, 2 * minorAxis); //taken from circle class 
    }

    /**
     * Sets the color of the ellipse.
     * 
     * @param c The new color for the ellipse (not null)
     * @pre c is not null
     * @post Ellipse color is updated to the specified color
     */
    public void setColor(Color c) {
        this.ellipseColor = c;
    }

    /**
     * Retrieves the color of the ellipse.
     * 
     * @return The color of the ellipse
     * @post Result is not null
     */
    public Color getColor() {
        return this.ellipseColor;
    }

    /**
     * Sets the length of the major axis of the ellipse.
     * 
     * @param majorAxis The new length of the major axis (must be greater than 0)
     * @pre majorAxis must be greater than 0
     * @post Major axis length is updated to the specified value
     */
    public void setMajorAxis(int majorAxis) {
        if (majorAxis < 0) {
            this.majorAxis = 20; 
        }
        else {
        this.majorAxis = majorAxis;
    }
    }

    /**
     * Retrieves the length of the major axis of the ellipse.
     * 
     * @return The length of the major axis
     * @pre object is not null 
     * @post Result is greater than 0
     */
    public int getMajorAxis() {
        return this.majorAxis;
    }

    /**
     * Sets the length of the minor axis of the ellipse.
     * 
     * @param minorAxis The new length of the minor axis (must be greater than 0)
     * @pre minorAxis must be greater than 0
     * @post Minor axis length is updated to the specified value
     */
    public void setMinorAxis(int minorAxis) {
       if (minorAxis < 0) {
        this.minorAxis = 20; 
    }
    else {
        this.minorAxis = minorAxis;
    }
    }

    /**
     * Retrieves the length of the minor axis of the ellipse.
     * 
     * @return The length of the minor axis
     * @pre not null 
     * @post Result is greater than 0
     */
    public int getMinorAxis() {
        return this.minorAxis;
    }
}
       

