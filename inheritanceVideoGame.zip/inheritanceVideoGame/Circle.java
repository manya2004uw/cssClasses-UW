import java.awt.*;

/**
 * Circle
 * ------
 * Represents a circle shape on a graphics canvas.
 * Extends the Shape class and implements methods for area calculation and drawing.
 * 
 */
public class Circle extends Shape {

    private int radius;         // The radius of the circle
    private Color circleColor;  // The color of the circle

    /**
     * Constructs a Circle object with the coordinates and radius, using th color RED.
     * 
     * @param x The x-coordinate of the center of the circle
     * @param y The y-coordinate of the center of the circle
     * @param radius The radius of the circle 
     * @pre radius must be greater than 0
     * @post constructs a circle instance 
     */
    public Circle(int x, int y, int radius) {
        super(x, y); //call super 
        if (radius < 0) { //if radius is less than 0 
            this.radius = 10; //change to default 10 
        }
        else {
        this.radius = radius; 
    }
        this.circleColor = Color.RED; // Default color is red
    }

    /**
     * Constructs a Circle object with the specified coordinates, radius, and color.
     * 
     * @param x The x-coordinate of the center of the circle
     * @param y The y-coordinate of the center of the circle
     * @param radius The radius of the circle 
     * @param c The color of the circle 
     * @pre radius must be greater than 0 and c is not null
     * @pre constructs a circle object 
     */
    public Circle(int x, int y, int radius, Color c) {
        super(x, y); //call parent constructor 
        if (radius < 0) { //if radius is less than 0 
            this.radius = 10; //change to default 10 
        }
        else {
        this.radius = radius; 
    }
        this.circleColor = c; //change color to parameter c 
    }

    /**
     * Calculates and returns the area of the circle.
     * 
     * @return The area of the circle (π * radius^2)
     * @post Result is non-negative and returns area of circle in double 
     */
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }

    /**
     * Draws the circle on the specified graphics context.
     * https://stackoverflow.com/questions/21208239/drawing-oval-using-drawoval-method
     * used for logic for fillOval and filling the oval 
     * @param g The graphics context on which to draw the circle
     * @pre none
     * @post Circle is drawn on the graphics context it might be drawn outside if getX() - radius are negative or the same for getY
     */
    @Override
    public void draw(Graphics g) {
        g.setColor(circleColor); //set oval
        g.fillOval(getX() - radius, getY() - radius, 2 * radius, 2 * radius); 
    }

    /**
     * Sets the color of the circle.
     * 
     * @param c The new color for the circle (not null)
     * @pre c is not null
     * @post Circle color is updated to the c
     */
    public void setColor(Color c) {
        this.circleColor = c;
    }

    /**
     * Retrieves the color of the circle.
     * 
     * @return The color of the circle
     * @pre Color is not null
     * @post returns color 
     */
    public Color getColor() {
        return this.circleColor;
    }

    /**
     * Sets the radius of the circle.
     * 
     * @param radius The new radius for the circle (must be greater than 0)
     * @pre radius must be greater than 0
     * @post Circle radius is updated to the specified value
     */
    public void setRadius(int radius) {
        if (radius < 0) { //if radius is less than 0 
            this.radius = 10; //change to default 10 
        }
        else {
        this.radius = radius; 
    }
    }

    /**
     * Retrieves the radius of the circle.
     * 
     * @return The radius of the circle
     * @pre radius is not null or the object called is not null 
     * @post Result is greater than 0
     */
    public int getRadius() {
        return this.radius;
    }
}
