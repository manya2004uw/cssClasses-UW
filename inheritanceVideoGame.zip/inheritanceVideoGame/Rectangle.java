import java.awt.*;

/**
 * Rectangle
 * ---------
 * Represents a rectangle shape on a graphics canvas.
 * Extends the Shape class and implements methods for area calculation and drawing.
 * 
 */
public class Rectangle extends Shape {

    private int width;              // The width of the rectangle
    private int height;             // The height of the rectangle
    private Color rectangleColor;   // The color of the rectangle

    /**
     * Constructs a Rectangle object with the specified coordinates, width, and height, using the default color (RED).
     * 
     * @param x The x-coordinate of the top-left corner of the rectangle
     * @param y The y-coordinate of the top-left corner of the rectangle
     * @param width The width of the rectangle (must be greater than 0)
     * @param height The height of the rectangle (must be greater than 0)
     * @pre width and height must be greater than 0
     * @post constructs a rectangle object 
     */
    public Rectangle(int x, int y, int width, int height) {
        super(x, y); //call parent constructor
        if (width < 0) {
            this.width = 20;
        }
        else {
        this.width = width;
    }
    if (height < 0) {
            this.height = 20;
        }
        else {
        this.height = height;
    }
        this.rectangleColor = Color.RED; // Default color is red
    }

    /**
     * Constructs a Rectangle object with the specified coordinates, width, height, and color.
     * 
     * @param x The x-coordinate of the top-left corner of the rectangle
     * @param y The y-coordinate of the top-left corner of the rectangle
     * @param width The width of the rectangle (must be greater than 0)
     * @param height The height of the rectangle (must be greater than 0)
     * @param c The color of the rectangle (not null)
     * @pre width and height must be greater than 0
     * @post constructs a rectangle obbject 
     */
    public Rectangle(int x, int y, int width, int height, Color c) {
        super(x, y); //call parent constructor 
        if (width < 0) {
            this.width = 20;
        }
        else {
        this.width = width;
    }
        if (height < 0) {
            this.height = 20;
        }
        else {
        this.height = height;
    }
        this.rectangleColor = c;
    }

    /**
     * Calculates and returns the area of the rectangle.
     * 
     * @return The area of the rectangle (width * height)
     * @pre rectange object is not null 
     * @post Result is non-negative
     */
    @Override
    public double getArea() {
        return width * height;
    }

    /**
     * Draws the rectangle on the specified graphics context.
     * 
     * @param g The graphics context on which to draw the rectangle
     * @pre rectangle is not null 
     * @post Rectangle is drawn on the graphics context
     */
    @Override
    public void draw(Graphics g) {
        g.setColor(rectangleColor); //sets color
        g.fillRect(getX(), getY(), width, height); //use fillRect
    }

    /**
     * Sets the color of the rectangle.
     * 
     * @param c The new color for the rectangle (not null)
     * @pre c is not null
     * @post Rectangle color is updated to the specified color
     */
    public void setColor(Color c) {
        this.rectangleColor = c;
    }

    /**
     * Retrieves the color of the rectangle.
     * 
     * @return The color of the rectangle
     * @post Result is not null
     */
    public Color getColor() {
        return this.rectangleColor;
    }

    /**
     * Sets the width of the rectangle.
     * 
     * @param width The new width for the rectangle (must be greater than 0)
     * @pre width must be greater than 0
     * @post Rectangle width is updated to the specified value
     */
    public void setWidth(int width) {
         if (width < 0) {
            this.width = 20;
        }
        else {
        this.width = width;
    }
    }

    /**
     * Retrieves the width of the rectangle.
     * 
     * @return The width of the rectangle
     * @post Result is greater than 0
     */
    public int getWidth() {
        return this.width;
    }

    /**
     * Sets the height of the rectangle.
     * 
     * @param height The new height for the rectangle (must be greater than 0)
     * @pre height must be greater than 0
     * @post Rectangle height is updated to the specified value
     */
    public void setHeight(int height) {
        if (height < 0) {
            this.height = 20;
        }
        else {
        this.height = height;
    }
    }

    /**
     * Retrieves the height of the rectangle.
     * 
     * @return The height of the rectangle
     * @post Result is greater than 0
     */
    public int getHeight() {
        return this.height;
    }
}

