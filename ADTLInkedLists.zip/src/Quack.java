public class Quack {
    protected class Node {
    protected Object data; 
    protected Node next; 

    protected Node() {
        data = null; 
        next = null; 
    }

    /* 
    protected Node(Object newData, Node newLink) {
        this.data = newData; 
        this.link = newLink; 
    }
    */

    protected Node(Object newData) {
        data = newData;
        next = null; 
    }

    protected Node(Object newData, Node next) {
        data = newData;
        next = next; 
    }
    }

    protected Node head = null; 

    protected void insert(Object newData, int index) {
        if (index < 0 ||index > this.size() ) {
            System.out.println("index is not possible to reach");
            return;
        }
        Node node = new Node(newData);
        if (head == null) {
            head = node;
        }
        else if(index == 0) {
            node.next = head; 
            this.head = node; 
        }
        else {
            Node current = head; 
            int tracking = 0; 

            while(current != null && tracking < index - 1) {
                current = current.next; 
                tracking++;

            }

            if (current == null){
            System.out.println("Index is out of bounds");
            }
            
            node.next = current.next; 
            current.next = node;
        }

        }

    protected Object remove(int index) {
        Object dataGone = null; 
        if (index < 0 || head == null) {
            System.out.println("Index is not reachable or your list is empty");
            return null;
        }
        else if (index == 0) {
              dataGone = head.data; 
              head = head.next;
        }
        else {
            Node current = head; 
            int currentIndex = 0; 

            while (current != null && currentIndex < index - 1) {
                current = current.next; 
                currentIndex++;
            }

            if (current == null || current.next == null) {
                System.out.println("Index is out of bounds");
                return null;
            }
            dataGone = current.data;
            current.next = current.next.next;
        }

        return dataGone;
       

    }

    protected void append(Object newData) {
        
        Node current = head;  
        //Node node = new Node(newData,current);

        if (head == null) {
            Node newNode = new Node();
          newNode.data = newData;
              newNode.next = head;
            head = newNode;
        }
        else {
            Node node = new Node(newData,current);

        while (current.next != null) {
            current = current.next;

        }

        current.next = node; 
        
        
        




        /*
         * Node newNode = new Node();
newNode.data = pushMe;
newNode.next = head;
head = newNode;
         */
    }
}

    protected void delete(int index) {
        Object dataGone = null; 
        if (index < 0 || head == null) {
            System.out.println("Index is not reachable or your list is empty");
            return;
        }
        else if (index == 0) {
              dataGone = head.data; 
              head = head.next;
        }
        else {
            Node current = head; 
            int currentIndex = 0; 

            while (current != null && currentIndex < index - 1) {
                current = current.next; 
                currentIndex++;
            }

            if (current == null || current.next == null) {
                System.out.println("Index is out of bounds");
                return;
            }
            dataGone = current.data;
            current.next = current.next.next;
        }

    }

    protected Object get(int index) {
        if (index < 0) {
            System.out.println("Error: Index out of bounds");
            return null;
        }
    
        Node current = head;
        int currentIndex = 0;
    
        // Traverse the list to find the node at the specified index
        while (current != null && currentIndex < index) {
            current = current.next;
            currentIndex++;
        }
    
        // Check if the index is out of bounds
        if (current == null) {
            System.out.println("Error: Index out of bounds");
            return null;
        }
    
        // Return the data of the node at the specified index
        return current.data;
        
    }

    public int size(){
        Node current = head;
        int count = 0; 
        if (current == null) {
            return 0; 
        }
        else {
            while(current != null) {
                current = current.next; 
                count++; 
            }
        }

        return count; 
    }

    public String toString(){
    Node currentPosition = head;
    String s = new String("");
       while (currentPosition != null){
         if (s.equals("")) {
            s += "" + currentPosition.data;
          } // so no space before first element
         else { 
            s += " " + currentPosition.data;
         }
    currentPosition = currentPosition.next;
    }
   return s;
    }

    public boolean isEmpty(){
        return head == null;
    }

    protected int indexOf(Object target){
        Node current = head; 
        int index = 0; 
        for (int i = 0; i < this.size(); i++) {
            if (current.data.equals(target)) {
                return index;
            }
            current = current.next;
            index++;

        }

        return -1; 
    }

    public boolean equals(Object other){
        if (other == null) return false;
       else if (this.getClass() != other.getClass()) return false;
       else {
        Quack o = (Quack) other;
        Node thisPosition = this.head;
        Node otherPosition = o.head;
      while (thisPosition != null && otherPosition != null){
       if (thisPosition.data != otherPosition.data) return false; // use .equals for objects
        else {
        thisPosition = thisPosition.next;
       otherPosition = otherPosition.next;
            }
         }
          if (thisPosition == null && otherPosition != null) return false;
          else if (thisPosition != null && otherPosition == null) return false;
          else return true; 
    }
}

public static void main(String [] args) {
    Quack empty = new Quack();
    Quack one = new Quack();
    Quack multiple = new Quack();
    Quack cop1 = new Quack();
    Quack cop2 = new Quack();
    Quack empty2 = new Quack(); 

    cop1.append(10);
    cop2.append(10);
    cop1.append(22);
    cop2.append(22);

	
    one.append(5);
    multiple.append(10);
    multiple.append(20);
    multiple.append(30);

    System.out.println("Empty (should print nothing): " + empty.toString());     // ( note the implicit call to toString()! )
    System.out.println("One (should print '5'): " + one.toString());

    System.out.println("Multiple (should print '10, 20, 30'): " + multiple.toString());	

    one.delete(0);
    multiple.delete(1);
    System.out.println("One (upon delete) (should be empty): " + one.toString());
    System.out.println("Multiple (upon delete) (should be '10, 30'): " + multiple.toString());

    System.out.println("Attempting an illicit insert at index 5. Error message should print: ");
    one.insert(400, 5);
    System.out.println("One (on insert) (should still be empty): " + one.toString());

    System.out.println("Should print out an error ");
    one.delete(0);

    System.out.println("cop1 and cop2 should return true " + cop1.equals(cop2));

    cop1.remove(1);
    System.out.println("should print out just 10 " + cop1.toString());

    System.out.println("Should print an error message ");
    cop1.remove(2);
    System.out.println(multiple.toString());
    System.out.println(multiple.size());

System.out.println("print the index of it should be equal to 1 " + multiple.indexOf(30));

multiple.remove(1);
System.out.println("method should return 10 " + multiple.toString());

System.out.println("Should print error message");
multiple.remove(2);

multiple.remove(0);
System.out.println("Should remove 0 and now it will be an empty list which should return true " + multiple.isEmpty());

System.out.println("Should print out true " + empty.equals(empty2));

Object insert = (Object) 5;
multiple.insert(insert,0);
System.out.println("should print out 5 " + multiple.toString());

System.out.println("Should print out 5 " + multiple.get(0));
System.out.println("Should print out error message and return null  " + multiple.get(1));







}
}
