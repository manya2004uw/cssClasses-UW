public class Stack extends Quack {
//protected Quack quack; 




    public void push(Object next){
     super.insert(next,0);
    }

    public Object pop(){
        Object got = super.get(0);
      super.remove(0);
      return got;
    }

    public Object peek(){
        return super.get(0);


    }

    public static void main(String [] args) {
      Stack s1 = new Stack();
      Stack s2 = new Stack();  
     Object insert1 = (Object) 3;
     Object insert2 = (Object) 2;
      s1.push(insert1);
      s1.push(insert2);
      s1.push(insert1);
      System.out.println(s1);

      s2.push(insert1);
      s2.push(insert2);
      s2.push(insert1);

      System.out.println("Should print true " + s1.equals(s2));

      s1.pop();
      s1.pop();
      s1.pop();
      s1.pop();
      System.out.println(s1);

      s1.push(insert1);
      System.out.println(s1.peek());

      System.out.println("Should print false " + s1.equals(s2));





    }
}
