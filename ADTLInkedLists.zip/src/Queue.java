public class Queue extends Quack {
    public void enqueue(Object next){
        super.insert(next,0);
    }

    public Object dequeue(){
        int toRemove = super.size()-1;
        Object removed = super.get(toRemove);
        super.remove(toRemove);

        return removed; 
        
    }

    public static void main(String [] args) {
        Queue q1 = new Queue();
        Queue q2 = new Queue();
        Queue q3 = new Queue();
        Object insert1 = (Object) 5;
        Object insert2 = (Object) 3;
        Object insert3 = (Object) 4;
        q1.enqueue(insert1);
        q1.enqueue(insert2);
        q1.enqueue(insert3);
        System.out.println("Should print 4 3 5 " + q1.toString());

        q1.dequeue();
        System.out.println("Should print out 4 3 " + q1.toString());

        System.out.println("Should print false " + q1.equals(q2));
        System.out.println("Should print out true " + q2.equals(q3));


    }
}
