public enum ExpenseCategory {
    FOOD,
   HOUSING,
   TRANSPORT,
   TRAVEL,
   ENTERTAINMENT,
   HEALTH,
   PERSONAL,
   EDUCATION,
   PETS,
   OTHER

}
