/* 
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.text.html.ListView;
JButton button;

public class myFrame  extends JFrame implements ActionListener{
     myFrame() {
          //JFrame

        ImageIcon image = new ImageIcon("src/glass copy.png");
       
        Border border = BorderFactory.createLineBorder(Color.pink,3);

         /*
        * Using a JPanel - acts as a container that stores other panels
        
    JPanel GreenPanel = new JPanel();
    GreenPanel.setBackground(Color.GREEN);
    //now set the bounds of the panel since layout is set as null
    GreenPanel.setBounds(0,0,100,100);

    JPanel BluePanel = new JPanel();
    BluePanel.setBackground(Color.BLUE);
    //now set the bounds of the panel since layout is set as null
    BluePanel.setBounds(100,100,250,200);

    /*
     * JButton is a button that performs an action when clicked on 
     * 
     
    JButton button = new JButton();
    button.setBounds(58,15,250,100);
   


      
      JLabel label = new JLabel();
       label.setText("Expense Tracker");
       label.setIcon(image);
       label.setHorizontalTextPosition(JLabel.CENTER); //set text left,center right
       label.setVerticalTextPosition(JLabel.TOP);
       label.setForeground(Color.WHITE);
       label.setFont(new Font("MV Boli)",Font.PLAIN,15));
       label.setIconTextGap(25);
       label.setVerticalAlignment(JLabel.TOP);
       label.setHorizontalAlignment(JLabel.CENTER);

       label.setBackground(Color.BLACK);//always use with label.setOpaque
       label.setOpaque(true);
       label.setBorder(border);
       label.setBounds(58,15,250,100);
       


       JFrame frame = new JFrame();
         
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//EXTT ON CLOSE
        // Set the size of the frame
        frame.setSize(400, 300);
        frame.setResizable(false);//prevent frame from being resized 
        frame.setLayout(null);//means you have to manually write the x and y coordinatts for the frame

        // Make the frame visible
       // BluePanel.add(label);
        frame.add(label);
        frame.getContentPane().setBackground(Color.CYAN); //change color of background
      //  frame.getContentPane().setBackground(new Color
        frame.setVisible(true);
        frame.add(button); 
        button.addActionListener(this);
      //  frame.add(GreenPanel);
     //   frame.add(BluePanel);
        //use frane.pack() to adjust all the components of the frame no need for setLayout(), setSize() or setB ounds, make sure you add all components before using oack
       //add to myFrame 


      


    }

   

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==button) {
            System.out.println("ok");

        }
    }

    public static void main (String [] args) {
        new myFrame();
    }
}

    
    
*/