
/* 
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.text.html.ListView;



    public class ExpenseTracker   {
   // create private objects
// arraylist of expenses as strings
//private ListView<String> expenseListView;
ArrayList<Expense> expenseList;
private Scanner userInput;
private JButton button;



public ExpenseTracker() {
       expenseList = new ArrayList<>();
       userInput = new Scanner(System.in);
   }




//method for adding to expenseList and to display


//Before expensetrac ker loads an image with all types of epenses should load
public void addExpense(double amount, String categoryInput) {
    ExpenseCategory category;
    try {
        category = ExpenseCategory.valueOf(categoryInput.toUpperCase());
    } catch (IllegalArgumentException e) {
        category = ExpenseCategory.OTHER;
    }

    Expense expense = new Expense(amount, category);
    expenseList.add(expense);
    System.out.println("Added: " + expense.toString());
}







public void initializeUI() {
    ImageIcon image = new ImageIcon("src/glass copy.png");
       
        Border border = BorderFactory.createLineBorder(Color.pink,3);

         
        // Using a JPanel - acts as a container that stores other panels
        
        
   
    

    
     //JButton is a button that performs an action when clicked on 
     
    
    
 
     JLayeredPane pane = new JLayeredPane();
     pane.setBounds(0,0,1000, 800);


      
      
       


       JFrame frame = new JFrame();
         frame.add(pane);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//EXTT ON CLOSE
        // Set the size of the frame
        frame.setSize(1000, 800);
        frame.setResizable(false);//prevent frame from being resized 
        frame.setLayout(null);//means you have to manually write the x and y coordinatts for the frame

        // Make the frame visible
       // BluePanel.add(label);

        frame.getContentPane().setBackground(Color.CYAN); //change color of background
      //  frame.getContentPane().setBackground(new Color
        frame.setVisible(true);


        JLabel label = new JLabel();
        label.setText("Expense Tracker");
        label.setIcon(image);
        label.setHorizontalTextPosition(JLabel.CENTER); //set text left,center right
        label.setVerticalTextPosition(JLabel.TOP);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("MV Boli)",Font.PLAIN,40));
        label.setIconTextGap(25);
        label.setVerticalAlignment(JLabel.TOP);
        label.setHorizontalAlignment(JLabel.CENTER);
 
        label.setBackground(Color.BLACK);//always use with label.setOpaque
        label.setOpaque(true);
        label.setBorder(border);
        label.setBounds(50, 20, 400, 300);
        frame.add(label);
    


    JPanel BlackPanel = new JPanel();
    BlackPanel.setBackground(Color.BLACK);
    //now set the bounds of the panel since layout is set as null
    BlackPanel.setBounds(100, 350, 200, 200);  // Adjusted bounds
    frame.add(BlackPanel);

    button = new JButton("add expense");
    button.setBounds(100, 350, 300, 200);  // Positioned button on the right
    button.setBackground(Color.pink);
    button.setVisible(true);
    button.addActionListener(e -> {
        if (e.getSource() == button) {
            frame.dispose();
            NewPage myPage = new NewPage(this);
        }
    });
    //button.setForeground(Color.WHITE);
    //button.setBorder(BorderFactory.createEtchedBorder());

    BlackPanel.add(button); 

    frame.revalidate();
    frame.repaint();
        
      //  frame.add(GreenPanel);
     //   frame.add(BluePanel);
        //use frane.pack() to adjust all the components of the frame no need for setLayout(), setSize() or setB ounds, make sure you add all components before using oack
       //add to myFrame 


      
      

    }

  
    public void showExpenses() {
        for (Expense expense : expenseList) {
            System.out.println(expense.toString());
        }
    }





public static void main(String[] args) {
  
   ExpenseTracker tracker = new ExpenseTracker();
   tracker.initializeUI();
   //System.out.println(tracker.addExpense());
  
   
}

*/
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.text.html.ListView;



public class ExpenseTracker {

    private ArrayList<Expense> expenseList;
    private JButton button;

    public ExpenseTracker() {
        expenseList = new ArrayList<>();
    }

    public void initializeUI() {
        ImageIcon image = new ImageIcon("src/glass copy.png");

        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.CYAN);
        frame.setVisible(true);

        JLabel label = new JLabel();
        label.setText("Expense Tracker");
        label.setIcon(image);
        label.setHorizontalTextPosition(JLabel.CENTER);
        label.setVerticalTextPosition(JLabel.TOP);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("MV Boli)", Font.PLAIN, 40));
        label.setIconTextGap(25);
        label.setVerticalAlignment(JLabel.TOP);
        label.setHorizontalAlignment(JLabel.CENTER);
        label.setBounds(50, 20, 400, 300);
        frame.add(label);

        JPanel BlackPanel = new JPanel();
        BlackPanel.setBackground(Color.BLACK);
        BlackPanel.setBounds(100, 350, 200, 200);
        frame.add(BlackPanel);

        button = new JButton("Add Expense");
        button.setBounds(100, 350, 300, 200);
        button.setBackground(Color.pink);
        button.setVisible(true);

        // Lambda to open NewPage and pass a reference to ExpenseTracker
        button.addActionListener(e -> {
            frame.dispose(); // Close the home frame
            new NewPage(this); // Open the expense input page and pass "this" as a reference
        });

        BlackPanel.add(button);
        frame.revalidate();
        frame.repaint();
    }

    public static void main(String[] args) {
        ExpenseTracker tracker = new ExpenseTracker();
        tracker.initializeUI();
    }
}


