/* 
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;

public class Example extends JFrame {

    public Example() {
        DefaultCategoryDataset dataset = createDataset();
        JFreeChart chart = ChartFactory.createBarChart(
                "Expense Tracker", // Chart title
                "Category", // X-Axis Label
                "Amount", // Y-Axis Label
                dataset);

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(800, 600));
        setContentPane(chartPanel);
    }

    private DefaultCategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(80, "Food", "Monday");
        dataset.addValue(50, "Transport", "Monday");
        dataset.addValue(90, "Food", "Tuesday");
        dataset.addValue(70, "Transport", "Tuesday");
        return dataset;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Example example = new Example();
            example.setSize(800, 600);
            example.setLocationRelativeTo(null);
            example.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            example.setVisible(true);
        });
    }
}
    */

    import org.jfree.chart.ChartFactory;
    import org.jfree.chart.ChartPanel;
    import org.jfree.chart.JFreeChart;
    import org.jfree.data.category.DefaultCategoryDataset;
    
    import javax.swing.*;
    import java.awt.*;
    import java.util.ArrayList;
    
    public class BarChartExpense {
        JFrame frame = new JFrame("Data Representation");
    
        public BarChartExpense(ArrayList<Expense> expenses) {
            JFreeChart chart = createChart(createDataset(expenses));
    
            frame.setLayout(new BorderLayout());
            frame.setSize(600, 400);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    
            ChartPanel chartPanel = new ChartPanel(chart);
            frame.add(chartPanel, BorderLayout.CENTER);
    
          
            JLabel infoLabel = new JLabel("Here is your data representation:");
            frame.add(infoLabel, BorderLayout.NORTH);
    
            frame.setVisible(true);
        }
    
        private DefaultCategoryDataset createDataset(ArrayList<Expense> expenses) {
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    
            // expenses by category
            for (Expense expense : expenses) {
                dataset.addValue(expense.getAmount(), "Expenses", expense.getCategory());
            }
    
            return dataset;
        }
    
        //JFreehcart stuff from yt
        private JFreeChart createChart(DefaultCategoryDataset dataset) {
            return ChartFactory.createBarChart(
                    "Expense Data",           // Chart title
                    "Category",               // X-axis label
                    "Amount",                 // Y-axis label
                    dataset,                  // Data
                    org.jfree.chart.plot.PlotOrientation.VERTICAL,  // Orientation
                    true,                     // Include legend
                    true,                     // Tooltips
                    false                     // URLs
            );
        }
    }
    