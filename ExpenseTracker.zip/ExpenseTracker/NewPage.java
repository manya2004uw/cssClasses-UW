import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class NewPage {

    JFrame frame = new JFrame();
    JLabel label = new JLabel("Enter your expense:");
    JLabel amountLabel = new JLabel("Amount:");
    JLabel categoryLabel = new JLabel("Category:");

    JTextField amountField = new JTextField();
    String[] categories = {
            "FOOD", "HOUSING", "TRANSPORT", "TRAVEL", "ENTERTAINMENT",
            "HEALTH", "PERSONAL", "EDUCATION", "PETS", "OTHER"
    };
    JComboBox<String> categoryDropdown = new JComboBox<>(categories);
    JButton submitButton = new JButton("Submit");
    JButton homeButton = new JButton("Back to Home");
    JButton viewDataButton = new JButton("View Data Representation");

    JTextArea expenseListArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(expenseListArea);

    ArrayList<Expense> expenseList = new ArrayList<>();
    ExpenseTracker homePage;

    NewPage(ExpenseTracker homePage) {
        this.homePage = homePage;

        frame.setLayout(null);

        label.setBounds(50, 20, 200, 30);
        frame.add(label);

        amountLabel.setBounds(50, 70, 100, 30);
        amountField.setBounds(150, 70, 200, 30);
        frame.add(amountLabel);
        frame.add(amountField);

        categoryLabel.setBounds(50, 120, 100, 30);
        categoryDropdown.setBounds(150, 120, 200, 30);
        frame.add(categoryLabel);
        frame.add(categoryDropdown);

        submitButton.setBounds(150, 170, 100, 30);
        frame.add(submitButton);

        scrollPane.setBounds(50, 220, 400, 200);
        expenseListArea.setEditable(false);
        frame.add(scrollPane);

        homeButton.setBounds(150, 440, 200, 30);
        frame.add(homeButton);

        viewDataButton.setBounds(150, 480, 200, 30);
        frame.add(viewDataButton);

        submitButton.addActionListener(e -> handleSubmit());
        homeButton.addActionListener(e -> {
            frame.dispose();
            homePage.initializeUI();
        });

       // viewDataButton.addActionListener(e -> new BarChartExpense(expenseList));
        viewDataButton.addActionListener(e -> new BarChartExpense(getExpenseData()));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 550);
        frame.setVisible(true);
    }

    private void handleSubmit() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            String category = (String) categoryDropdown.getSelectedItem();

            // Add the expense to the list
            Expense newExpense = new Expense(amount, category);
            expenseList.add(newExpense);

            // Update the JTextArea
            updateExpenseListArea();

            // Show a success message
            JOptionPane.showMessageDialog(frame,
                    "Expense Added:\nAmount: " + amount + " | Category: " + category,
                    "Expense Added",
                    JOptionPane.INFORMATION_MESSAGE);

            // Clear the input fields
            amountField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame,
                    "Please enter a valid amount.",
                    "Invalid Input",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    public ArrayList<Expense> getExpenseData() {
        return expenseList;
    }

    private void updateExpenseListArea() {
        StringBuilder sb = new StringBuilder();
        for (Expense expense : expenseList) {
            sb.append("Amount: ").append(expense.getAmount())
              .append(" | Category: ").append(expense.getCategory())
              .append("\n");
        }
        expenseListArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        new NewPage(new ExpenseTracker());
    }
}
